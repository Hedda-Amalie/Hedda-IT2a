#Import.


#opne json file.
#leg til bestilinger.
#fulført bestilinger "Jeg har levert inn pengene for lånet"
#Meny.
#Hovedprogrammet som kjører dette.