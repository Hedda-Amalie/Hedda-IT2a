Busser = [
    {
        "busname": "Herpes",
        "type": "a",
        "busID": "2081ac8d-38b8-458d-8716-1a0aff0bcbe0",
        "rentalID": "",
        "seats": "7",
        "price": "1250",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Chillguy",
        "type": "a",
        "busID": "e7cec7f6-8356-4f22-9637-0c3d5463fab5",
        "rentalID": "",
        "seats": "7",
        "price": "1250",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Kraken",
        "type": "a",
        "busID": "2e04aa79-e83e-47ab-b48c-19e9969fc5ec",
        "rentalID": "",
        "seats": "7",
        "price": "1250",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Seaweed",
        "type": "b",
        "busID": "2040d91d-e32a-4f25-b243-c0c269aa497b",
        "rentalID": "",
        "seats": "15",
        "price": "1600",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Olje",
        "type": "b",
        "busID": "e6786e26-cc18-4cba-bc6d-5c6604fe84cb",
        "rentalID": "",
        "seats": "15",
        "price": "1600",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Odin",
        "type": "b",
        "busID": "c425e681-1ca7-41f4-948c-54a1b07b6814",
        "rentalID": "",
        "seats": "15",
        "price": "1600",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Mattchew",
        "type": "c",
        "busID": "a0fe3531-6457-45c3-b562-7cc59b5ce76b",
        "rentalID": "",
        "seats": "23",
        "price": "1900",
        "priceKM": "90",
        "avaiable": True
    },
    {
        "busname": "Femboy",
        "type": "c",
        "busID": "b5fd35a1-3731-47f8-bf4d-f61cd6cabee4",
        "rentalID": "",
        "seats": "23",
        "price": "1900",
        "priceKM": "90",
        "avaiable": True
    }
]